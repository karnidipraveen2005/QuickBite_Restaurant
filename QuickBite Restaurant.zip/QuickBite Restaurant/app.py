from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient
from bson.objectid import ObjectId  # Import ObjectId to work with MongoDB document IDs

# Initialize the Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a strong secret key

# Set up MongoDB connection
cluster = MongoClient("127.0.0.1:27017")
db = cluster['QuickBite']  # Your database name
users = db['users']        # Your users collection
orders = db['orders']      # Your orders collection

@app.route('/')
def index():
    return render_template('login.html')  # Redirect to login.html

@app.route('/login.html', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = users.find_one({"email": username})  # Check user by email
        if user and user["password"] == password:  # Verify password
            session['username'] = user["firstname"]  # Store the user's first name in session
            session['user_email'] = username  # Store the user's email for order tracking
            return redirect(url_for('home'))  # Redirect to home page
        return render_template('login.html', status="Invalid credentials")  # Show error message
    
    return render_template('login.html')  # Render login page for GET request

@app.route('/registerdata', methods=['POST'])
def registerdata():
    firstname = request.form.get('firstname')
    lastname = request.form.get('lastname')
    email = request.form.get('email')
    password = request.form.get('password')

    # Check if the user already exists
    if users.find_one({"email": email}):
        return render_template('login.html', status="Email already exists.")  # Show error message
    
    # Insert new user into the database
    users.insert_one({
        "firstname": firstname,
        "lastname": lastname,
        "email": email,
        "password": password
    })
    
    return render_template('login.html', status="Registration successful, please log in.")  # Show success message

@app.route('/forgot.html', methods=['GET', 'POST'])
def forgot():
    if request.method == 'POST':
        email = request.form.get('email')
        new_password = request.form.get('new-password')
        confirm_password = request.form.get('confirm-password')

        user = users.find_one({"email": email})  # Check if the user exists

        if user:
            if new_password == confirm_password:
                # Update password in the database
                users.update_one({"email": email}, {"$set": {"password": new_password}})
                return render_template('forgot.html', status="Password updated successfully. Please log in.")
            else:
                return render_template('forgot.html', status="New passwords do not match.")
        else:
            return render_template('forgot.html', status="Email does not exist.")

    return render_template('forgot.html')

@app.route('/home.html')
def home():
    username = session.get('username', 'Guest')  # Retrieve username from session
    return render_template('home.html', username=username)  # Pass username to template

@app.route('/menu.html')
def menu():
    return render_template('menu.html')

@app.route('/blog.html')
def blog():
    return render_template('blog.html')

@app.route('/service.html')
def service():
    return render_template('service.html')

@app.route('/aboutus.html')
def aboutus():
    return render_template('aboutus.html')

@app.route('/profile.html')
def profile():
    user_email = session.get('user_email')  # Retrieve user email from session
    if not user_email:
        return redirect(url_for('login'))  # Redirect if user is not logged in

    user = users.find_one({"email": user_email})  # Get user data
    orders_list = []  # Initialize orders to an empty list

    if user:  # Check if the user exists
        orders_cursor = orders.find({"user_email": user_email})  # Get user orders
        orders_list = list(orders_cursor)  # Convert cursor to list
    else:
        return redirect(url_for('login'))  # Redirect if user not found

    return render_template('profile.html', user=user, orders=orders_list)  # Pass user and orders to template

@app.route('/order.html')
def order():
    item_name = request.args.get('item_name')  # Get item name from query parameters
    username = session.get('username', 'Guest')  # Retrieve username from session
    return render_template('order.html', item_name=item_name, username=username)  # Pass username to template

@app.route('/editprofile.html', methods=['GET', 'POST'])
def editprofile():
    user_email = session.get('user_email')  # Retrieve user email from session
    if not user_email:
        return redirect(url_for('login'))  # Redirect if user is not logged in

    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')

        # Update user profile in the database
        users.update_one({"email": user_email}, {"$set": {"firstname": name, "email": email, "phone": phone}})

        return redirect(url_for('profile'))  # Redirect to profile page after updating

    user = users.find_one({"email": user_email})  # Get user data for GET request
    return render_template('editprofile.html', user=user)  # Pass user data to the template

@app.route('/changepass.html', methods=['GET', 'POST'])
def changepass():
    user_email = session.get('user_email')  # Retrieve user email from session

    if not user_email:
        return redirect(url_for('login'))  # Redirect if user is not logged in

    if request.method == 'POST':
        current_password = request.form.get('current-password')
        new_password = request.form.get('new-password')
        confirm_password = request.form.get('confirm-password')

        user = users.find_one({"email": user_email})  # Get user data

        # Check if the current password matches
        if user and user["password"] == current_password:
            if new_password == confirm_password:
                # Update password in the database
                users.update_one({"email": user_email}, {"$set": {"password": new_password}})
                return render_template('changepass.html', status="Password changed successfully.")
            else:
                return render_template('changepass.html', status="New passwords do not match.")
        else:
            return render_template('changepass.html', status="Current password is incorrect.")

    return render_template('changepass.html')  # Render change password page for GET request

@app.route('/hblog.html')
def hblog():
    return render_template('hblog.html')

@app.route('/hservice.html')
def hservice():
    return render_template('hservice.html')

@app.route('/haboutus.html')
def haboutus():
    return render_template('haboutus.html')

@app.route('/order_item', methods=['POST'])
def order_item():
    item_name = request.form.get('item_name')
    item_price = request.form.get('item_price')
    user_email = session.get('user_email')  # Retrieve user email from session

    if not user_email:
        return redirect(url_for('login'))  # Redirect if user is not logged in

    # Store the order in the database
    orders.insert_one({
        "user_email": user_email,
        "item_name": item_name,
        "item_price": item_price,
        "status": "Ordered"  # You can add status for tracking
    })

    return redirect(url_for('order', item_name=item_name))  # Redirect to order confirmation page with item name

@app.route('/cancel_order/<order_id>', methods=['POST'])
def cancel_order(order_id):
    user_email = session.get('user_email')  # Retrieve user email from session

    if not user_email:
        return redirect(url_for('login'))  # Redirect if user is not logged in

    # Delete the order from the database
    orders.delete_one({"_id": ObjectId(order_id), "user_email": user_email})

    return redirect(url_for('profile'))  # Redirect back to profile page after cancellation

if __name__ == '__main__':
    app.run(debug=True)
